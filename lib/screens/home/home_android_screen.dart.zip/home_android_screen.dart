import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:native_kit/store/app_state.dart';
import 'package:redux/redux.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:io';

import 'package:flutter_webview_pro/webview_flutter.dart';

class ViewModel {
  final bool isLoading;
  final String? webVersionUrl;

  ViewModel({
    required this.isLoading,
    this.webVersionUrl,
  });

  factory ViewModel.fromStore(Store<AppState> store) {
    return ViewModel(
      isLoading: store.state.system.isFetching,
      webVersionUrl: store.state.system.setting?.webVersionUrl,
    );
  }
}

/// Android use
class HomeAndroidScreen extends StatefulWidget {
  HomeAndroidScreen({Key? key}) : super(key: key);

  @override
  _HomeAndroidScreenState createState() => _HomeAndroidScreenState();
}

class _HomeAndroidScreenState extends State<HomeAndroidScreen> {
  late WebViewController _controller;

  @override
  void initState() {
    super.initState();
    // Enable virtual display.
    // if (Platform.isAndroid) WebView.platform = AndroidWebView();
    if (Platform.isAndroid) WebView.platform = SurfaceAndroidWebView();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: () async {
          _controller.goBack();
          return false;
        },
        child: StoreConnector<AppState, ViewModel>(
            converter: (store) => ViewModel.fromStore(store),
            builder: (context, vm) {
              final webVersionUrl = vm.webVersionUrl;
              if (webVersionUrl == null || webVersionUrl == '') {
                return Container(
                    color: Color.fromRGBO(0, 0, 0, 1),
                    child: Center(
                      child: Text('Not WebVersionUrl'),
                    ));
              }

              return Container(
                color: Color.fromRGBO(0, 0, 0, 1),
                child: SafeArea(
                  bottom: true,
                  top: true,
                  child: WebView(
                    allowsInlineMediaPlayback: true,
                    gestureNavigationEnabled: true,
                    // backgroundColor: Color.fromRGBO(0, 0, 0, 1),
                    javascriptMode: JavascriptMode.unrestricted,
                    initialUrl: webVersionUrl,
                    userAgent: 'WebView Mozilla/5.0 (iPhone; CPU iPhone OS 14_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148',
                    onWebViewCreated: (WebViewController webViewController) {
                      _controller = webViewController;
                    },
                    navigationDelegate: (NavigationRequest request) {
                      if (request.url.startsWith(webVersionUrl)) {
                        return NavigationDecision.navigate;
                      } else {
                        launch(
                          request.url,
                          forceSafariVC: false,
                          enableJavaScript: true,
                        );
                        return NavigationDecision.prevent;
                      }
                    },
                  ),
                ),
              );
            }));
  }
}
